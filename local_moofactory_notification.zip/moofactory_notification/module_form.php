<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Manage module notifications form.
 *
 * @package     local_moofactory_notification
 * @copyright   2020 Patrick ROCHET <patrick.r@lmsfactory.com>
 * @license     http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die;

require_once($CFG->libdir.'/formslib.php');
require_once('lib.php');

class module_form extends moodleform {
    public function definition() {
        global $CFG, $DB, $PAGE;

        $mform = $this->_form;
        $courseid = $this->_customdata['courseid'];
        $id = $this->_customdata['id'];


        $mform->addElement('hidden', 'courseid');
        $mform->setType('courseid', PARAM_RAW);
        $mform->setConstant('courseid', $courseid);

        $mform->addElement('hidden', 'id', $id);
        $mform->setType('id', PARAM_RAW);

        $mform->addElement('html', '<br>');

        $moduleeventsname = 'moduleevents_'.$courseid.'_'.$id;
        $mform->addElement('checkbox', $moduleeventsname, get_string('moduleevents', 'local_moofactory_notification'));
        $moduleeventsvalue = get_config('local_moofactory_notification', $moduleeventsname);
        $mform->setDefault($moduleeventsname, $moduleeventsvalue);

        $modulecheckavailabilityname = 'modulecheckavailability_'.$courseid.'_'.$id;
        if(empty($moduleeventsvalue)){
            $mform->addElement('checkbox', $modulecheckavailabilityname, get_string('modulecheckavailability', 'local_moofactory_notification'), '', array('disabled' => 'disabled'));
        }
        else{
            $mform->addElement('checkbox', $modulecheckavailabilityname, get_string('modulecheckavailability', 'local_moofactory_notification'));
        }

        $value = get_config('local_moofactory_notification', $modulecheckavailabilityname);
        if($value === false){
            $value = local_moofactory_notification_getCustomfield($courseid, 'courseeventscheckavailability', 'checkbox');
        }
        $mform->setDefault($modulecheckavailabilityname, $value);

        $modulenotificationname = 'modulenotification_'.$courseid.'_'.$id;
        $records = $DB->get_records('local_mf_notification', array('type'=>'courseevent'));
        foreach($records as $record) {
            $options[$record->id] = $record->name;
        }
        if(empty($moduleeventsvalue)){
            $mform->addElement('select', $modulenotificationname, get_string('usednotification', 'local_moofactory_notification'), $options, array('disabled' => 'disabled'));
        }
        else{
            $mform->addElement('select', $modulenotificationname, get_string('usednotification', 'local_moofactory_notification'), $options);
        }

        $value = get_config('local_moofactory_notification', $modulenotificationname);
        if(empty($value)){
            $value = (int)local_moofactory_notification_getCustomfield($courseid, 'courseeventsnotification', 'select');
            if(!empty($value)){
                $value--;
                $courseeventsnotifications = array_values($records);
                $value = $courseeventsnotifications[$value]->id;
            }
            else{
                $value = get_config('local_moofactory_notification', 'courseseventsnotification');
            }
        }
        $mform->setDefault($modulenotificationname, $value);

        $mform->addElement('html', '<hr>');

        $configvars = ['daysbeforeevents1', 'hoursbeforeevents1', 'daysbeforeevents2', 'hoursbeforeevents2', 'daysbeforeevents3', 'hoursbeforeevents3'];
        foreach($configvars as $configvar){
            $name = 'module'.$configvar.'_'.$courseid.'_'.$id;
            if(empty($moduleeventsvalue)){
                $mform->addElement('text', $name, get_string($configvar, 'local_moofactory_notification'), array('maxlength' => 3, 'size' => 3, 'disabled' => 'disabled'));
            }
            else{
                $mform->addElement('text', $name, get_string($configvar, 'local_moofactory_notification'), array('maxlength' => 3, 'size' => 3));
            }
            $mform->setType($name, PARAM_TEXT);
            
            $value = get_config('local_moofactory_notification', $name);
            if($value === false){
                $value = local_moofactory_notification_getCustomfield($courseid, $configvar, 'text');
            }
            $mform->setDefault($name, $value);
            $mform->addRule($name, get_string('notanumber', 'local_moofactory_notification'), 'numeric', null, 'client');
            $mform->addElement('html', html_writer::start_tag('div', array('class' => 'form-group row fitem')));
            $mform->addElement('html', html_writer::start_tag('div', array('class' => 'col-md-3')));
            $mform->addElement('html', html_writer::end_tag('div'));
            $mform->addElement('html', html_writer::start_tag('div', array('class' => 'col-md-9')));
            $mform->addElement('html', get_string($configvar.'_desc', 'local_moofactory_notification'));
            $mform->addElement('html', html_writer::end_tag('div'));
            $mform->addElement('html', html_writer::end_tag('div'));
            $mform->addElement('html', '<br>');
        }

        $mform->addElement('html', html_writer::start_tag('div', array('class' => 'form-group row fitem')));
        $mform->addElement('html', html_writer::start_tag('div', array('class' => 'col-md-12')));
        $mform->addElement('html', get_string('modulereset', 'local_moofactory_notification'));
        $mform->addElement('html', html_writer::end_tag('div'));
        $mform->addElement('html', html_writer::end_tag('div'));
        $mform->addElement('html', '<br>');


        $this->add_action_buttons();


        $js = "$('#id_$moduleeventsname').change(function(){";
        $js .= "    if($('#id_$moduleeventsname').is(':checked')){";
        $js .= "        $('#id_$modulecheckavailabilityname').removeAttr('disabled');";
        $js .= "        $('#id_$modulenotificationname').removeAttr('disabled');";
        foreach($configvars as $configvar){
            $name = 'id_module'.$configvar.'_'.$courseid.'_'.$id;
            $js .= "        $('#$name').removeAttr('disabled');";
        }
        $js .= "    }";
        $js .= "    else{";
        $js .= "        $('#id_$modulecheckavailabilityname').attr('disabled', 'disabled');";
        $js .= "        $('#id_$modulenotificationname').attr('disabled', 'disabled');";
            foreach($configvars as $configvar){
            $name = 'id_module'.$configvar.'_'.$courseid.'_'.$id;
            $js .= "        $('#$name').attr('disabled', 'disabled');";
        }
        $js .= "    }";
        $js .= "});";

        $PAGE->requires->js_init_code($js, true);
    }

    public function validation($data, $files) {
        /*global $DB;
        $errors = parent::validation($data, $files);


        $data  = (object)$data;
        foreach ($data as $key => $value) {
            if(strpos($key, "module") === 0){
                if(!(is_numeric($value) || $value == "")){
                    $errors[$key] = get_string('notanumber', 'local_moofactory_notification');
                }
            }
        }
        return $errors;*/
    }

}

